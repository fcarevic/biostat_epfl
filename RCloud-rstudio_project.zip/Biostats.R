library(plm)
library(ggplot2)
library(psych)
library(gridExtra)
library(MASS)
library(tidyverse)
library(broom)
library(GGally)

#LOADING DATA
# Define column names
column.names = c("pillar_id", "mine_seam", "depth", 
                 "height", "width", "wh_ratio" ,
                 "roadw_width", "uniaxial_compress", "strength", 
               "stress", "ss_ratio", "stability")

# Load data
data<-read.table("./ss.txt", sep=",", header=FALSE, col.names =  column.names)

# Print summary
summary(data)
str(data)


#EXPLORATORY DATA ANALYSIS
# Remove pillar ID and mine_seam columns - they are useless
data <- subset(data, select = -c(pillar_id, mine_seam))

# Convert to categorical
data$stability<- as.factor(data$stability)
df = data


# Hostrogram plots
ggplot(gather(subset(df, select = -c(stability))), aes(x=value)) + 
  geom_histogram(bins = 10) + 
  facet_wrap(~key, scales = 'free_x')


# Bivariate conditional density plots
par(mfrow = c(1, 3))
 cdplot(factor(stability) ~ width, data = df, xlab = 'Width', ylab = 'Stability')
 cdplot(factor(stability) ~ height, data = df, xlab = 'Height', ylab = 'Stability')
 cdplot(factor(stability) ~ wh_ratio, data = df,xlab = 'Width to Height ratio', ylab = 'Stability')
 par(mfrow = c(1, 3))
 cdplot(factor(stability) ~ roadw_width, data = df, xlab = 'Road width', ylab = 'Stability')
 cdplot(factor(stability) ~ depth, data = df, xlab = 'Depth', ylab = 'Stability')
 cdplot(factor(stability) ~ uniaxial_compress, data = df, xlab = 'Uniaxial compression strength', ylab = 'Stability')
 par(mfrow = c(1, 3))
 cdplot(factor(stability) ~ strength, data = df, xlab = 'Strength', ylab = 'Stability')
 cdplot(factor(stability) ~ stress, data = df, xlab = 'Stress', ylab = 'Stability')
 cdplot(factor(stability) ~ ss_ratio, data = df, xlab = 'Strength to Stress ratio', ylab = 'Stability')

 # Scatter plot matrix with scatter/histogram/correlation
 plt_data = subset(df, select= -c(stability))
 ggpairs(data = df,columns = 1:9, 
         aes(color = stability,  # Color by group (cat. variable)
                              alpha = 0.5))

# TRAINING THE MODEL

# Extracting features 
x = data.matrix(subset(df, select=c(ss_ratio, strength)))
y = df$stability

# Training with regression
tmp <-cv.glmnet(x,y, alpha=0, family=binomial)
model <- glmnet(x, y, family=binomial, alpha=0, lambda = tmp$lambda.1se)
summary(model)

#Print model coefficients
exp(coefficients(model))

# ASSUMTION CHECKS

# Linearity assumption check
probabilities <- predict(model,x, type = "response")

mydata <- subset(df, select=c(ss_ratio, strength))
predictors <- colnames(mydata)

# Bind the logit and tidying the data for plot
mydata <- mydata %>%
  mutate(logit = log(probabilities/(1-probabilities))) %>%
  gather(key = "predictors", value = "predictor.value", -logit)

ggplot(mydata, aes(logit, predictor.value))+
  geom_point(size = 0.5, alpha = 0.5) +
  geom_smooth(formula =  'y~x', method = "loess") + 
  theme_bw() + 
  facet_wrap(~predictors, scales = "free_y") + ylab("Predictor value")

